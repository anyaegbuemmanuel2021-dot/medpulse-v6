# MedPulse V6 — Complete Deployment Guide

> **TikTok for Healthcare** — Short-form medical videos, livestreams, verified credentials, communities, and AI-powered learning.

---

## Table of Contents

1. [Project Structure](#1-project-structure)
2. [Tech Stack](#2-tech-stack)
3. [Prerequisites](#3-prerequisites)
4. [Firebase Setup](#4-firebase-setup)
5. [Local Development](#5-local-development)
6. [Deploy to Vercel](#6-deploy-to-vercel) ← Recommended
7. [Deploy to Netlify](#7-deploy-to-netlify)
8. [Deploy Firebase (Rules + Functions)](#8-deploy-firebase-rules--functions)
9. [Environment Variables Reference](#9-environment-variables-reference)
10. [Post-Deploy Checklist](#10-post-deploy-checklist)
11. [Custom Domain Setup](#11-custom-domain-setup)
12. [Troubleshooting](#12-troubleshooting)

---

## 1. Project Structure

```
medpulse-v6/
├── app/                        # Next.js 15 App Router
│   ├── page.tsx                # Index / Landing page
│   ├── layout.tsx              # Root layout
│   ├── feed/page.tsx           # Main feed (TikTok-style)
│   ├── auth/login/page.tsx     # Login
│   ├── auth/register/page.tsx  # Registration
│   ├── search/page.tsx         # Search
│   ├── live/page.tsx           # Livestreams
│   ├── create/page.tsx         # Content creation
│   ├── dashboard/page.tsx      # Creator dashboard
│   ├── analytics/page.tsx      # Analytics
│   ├── premium/page.tsx        # Premium subscription
│   ├── chat/                   # Messaging
│   ├── communities/            # Communities
│   ├── profile/                # User profiles
│   ├── hashtag/                # Hashtag pages
│   ├── notifications/          # Notifications
│   ├── settings/               # Settings
│   └── admin/                  # Admin panel
├── components/                 # Reusable React components
│   ├── ui/                     # Base UI (Button, Input, Modal)
│   ├── MessagingComponents.tsx # Messaging UI
│   └── AdminPages.tsx          # Admin UI components
├── services/                   # Firebase/business logic (30+ services)
│   ├── auth.service.ts
│   ├── feed.service.v5.ts
│   ├── messaging.service.ts
│   ├── rbac.service.ts
│   ├── automation-rules.service.ts
│   └── ... (30+ services)
├── hooks/                      # React hooks
├── lib/
│   └── firebase.ts             # Firebase singleton (UPDATED)
├── config/
│   └── index.ts                # All env-based config
├── providers/index.tsx         # QueryClient + Firebase init
├── functions/src/              # Cloud Functions (Node 20)
├── middleware.ts               # Next.js edge middleware (auth guard)
├── firestore.rules             # Firestore security rules
├── storage.rules               # Storage security rules
├── firebase.json               # Firebase project config
├── next.config.js              # Next.js config
├── vercel.json                 # Vercel deployment config
├── netlify.toml                # Netlify deployment config
└── .env.example                # Environment variable template
```

---

## 2. Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Next.js 15, React 18, TypeScript, Tailwind CSS |
| Backend / DB | Firebase (Firestore, Auth, Storage, Functions) |
| Media | Cloudinary (video/image upload & CDN) |
| State | Zustand + React Query |
| UI | Lucide Icons, Framer Motion |
| Deployment | Vercel (recommended) or Netlify |
| Functions | Firebase Cloud Functions (Node 20) |

---

## 3. Prerequisites

Install these before continuing:

```bash
# Node.js 20+
node --version   # should show v20+

# npm 10+
npm --version    # should show 10+

# Firebase CLI
npm install -g firebase-tools
firebase --version   # should show 13+

# Vercel CLI (if deploying to Vercel)
npm install -g vercel
vercel --version

# Netlify CLI (if deploying to Netlify)
npm install -g netlify-cli
netlify --version
```

---

## 4. Firebase Setup

### Step 4.1 — Create Firebase Project

1. Go to [https://console.firebase.google.com](https://console.firebase.google.com)
2. Click **"Add project"**
3. Name it `medpulse-v6` (or your preferred name)
4. Enable Google Analytics → choose or create an Analytics account → **Create project**

### Step 4.2 — Enable Services

In the Firebase Console sidebar:

**Authentication**
- Build → Authentication → Get Started
- Sign-in method → Enable: **Email/Password**, **Google**, **Phone**
- For Google: download service account later (Step 4.5)

**Firestore Database**
- Build → Firestore Database → Create database
- Choose **"Start in production mode"** (rules are already configured)
- Select a region close to your users (e.g. `us-central`, `europe-west`)

**Storage**
- Build → Storage → Get Started
- Start in production mode
- Same region as Firestore

**Functions**
- Build → Functions → Get Started
- Upgrade to **Blaze plan** (pay-as-you-go) — required for Functions

### Step 4.3 — Get Your Firebase Config

1. Project Overview → Project settings (gear icon)
2. Under "Your apps" → click **</>** (Web)
3. App nickname: `MedPulse Web` → Register app
4. Copy the `firebaseConfig` object — you'll need these values for env variables

### Step 4.4 — Update .firebaserc

Open `.firebaserc` and replace `your-firebase-project-id` with your actual project ID:

```json
{
  "projects": {
    "default": "medpulse-v6",
    "production": "medpulse-v6"
  }
}
```

### Step 4.5 — Service Account Key (for Cloud Functions / Admin SDK)

1. Firebase Console → Project settings → **Service accounts** tab
2. Click **"Generate new private key"** → Download JSON
3. Open the JSON file and copy these values for your env:
   - `project_id` → `FIREBASE_ADMIN_PROJECT_ID`
   - `client_email` → `FIREBASE_ADMIN_CLIENT_EMAIL`
   - `private_key` → `FIREBASE_ADMIN_PRIVATE_KEY`

> **NEVER commit the JSON file or private key to Git.**

---

## 5. Local Development

```bash
# 1. Install dependencies
npm install

# 2. Copy env template
cp .env.example .env.local

# 3. Fill in .env.local with your Firebase config (from Step 4.3)
# Open .env.local in your editor and paste the values

# 4. Run development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

You should see the MedPulse landing page. Click "Browse as guest" to view the feed.

### Optional: Run Firebase Emulators (local backend)

```bash
firebase emulators:start
```

Emulator UI opens at [http://localhost:4000](http://localhost:4000)

---

## 6. Deploy to Vercel

**Vercel is the recommended host for Next.js.**

### Option A — Deploy via Vercel Dashboard (Easiest)

1. Push your code to a GitHub repository:
   ```bash
   git init
   git add .
   git commit -m "Initial MedPulse V6"
   git remote add origin https://github.com/YOUR_USERNAME/medpulse-v6.git
   git push -u origin main
   ```

2. Go to [https://vercel.com/new](https://vercel.com/new)
3. Click **"Import Git Repository"**
4. Select your `medpulse-v6` repo
5. Framework Preset: **Next.js** (auto-detected)
6. **Environment Variables** — click "Add" for each:

   ```
   NEXT_PUBLIC_FIREBASE_API_KEY          = your_value
   NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN      = your_project.firebaseapp.com
   NEXT_PUBLIC_FIREBASE_PROJECT_ID       = your_project_id
   NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET   = your_project.appspot.com
   NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID = your_sender_id
   NEXT_PUBLIC_FIREBASE_APP_ID           = your_app_id
   NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID   = G-XXXXXXXXXX
   FIREBASE_ADMIN_PROJECT_ID             = your_project_id
   FIREBASE_ADMIN_CLIENT_EMAIL           = your_service_account_email
   FIREBASE_ADMIN_PRIVATE_KEY            = your_private_key
   NEXT_PUBLIC_FUNCTIONS_URL             = https://us-central1-YOUR_PROJECT.cloudfunctions.net
   ```

7. Click **"Deploy"**
8. Wait ~2 minutes — Vercel builds and deploys automatically
9. Your app is live at `https://medpulse-v6.vercel.app` (or your custom domain)

### Option B — Deploy via Vercel CLI

```bash
# Login to Vercel
vercel login

# Deploy (first time — interactive setup)
vercel

# Follow the prompts:
# - Set up and deploy? Yes
# - Which scope? Your account
# - Link to existing project? No → create new
# - Project name: medpulse-v6
# - Directory: ./  (current directory)

# Add environment variables
vercel env add NEXT_PUBLIC_FIREBASE_API_KEY
# (paste value, press Enter, select "Production", "Preview", "Development")
# Repeat for all env variables

# Deploy to production
vercel --prod
```

### Update Firebase Auth Domain

After deploying to Vercel, add your Vercel URL to Firebase Auth:

1. Firebase Console → Authentication → Settings → **Authorized domains**
2. Click "Add domain"
3. Add: `medpulse-v6.vercel.app` (or your custom domain)

---

## 7. Deploy to Netlify

### Option A — Netlify Dashboard

1. Install the Next.js plugin first:
   ```bash
   npm install -D @netlify/plugin-nextjs
   ```

2. Push to GitHub (same as Vercel Step 6, Option A, steps 1)

3. Go to [https://app.netlify.com/start](https://app.netlify.com/start)
4. Click **"Import from Git"** → Connect GitHub → Select repo
5. Build settings (auto-filled from `netlify.toml`):
   - Build command: `npm run build`
   - Publish directory: `.next`
6. **Environment variables** → "Add environment variables"
   - Add all the same variables as listed in Vercel Option A, Step 6
7. Click **"Deploy site"**

### Option B — Netlify CLI

```bash
# Login
netlify login

# Initialize
netlify init

# Set environment variables
netlify env:set NEXT_PUBLIC_FIREBASE_API_KEY "your_value"
# Repeat for all variables

# Deploy
netlify deploy --prod
```

### Update Firebase Auth Domain for Netlify

Same as Vercel: Firebase Console → Auth → Settings → Authorized domains → Add your Netlify URL.

---

## 8. Deploy Firebase (Rules + Functions)

Run these from the project root after your site is live:

```bash
# Login to Firebase
firebase login

# Select your project
firebase use your-project-id

# Deploy Firestore security rules
firebase deploy --only firestore:rules

# Deploy Storage security rules
firebase deploy --only storage:rules

# Deploy Firestore indexes
firebase deploy --only firestore:indexes

# Install functions dependencies first
cd functions && npm install && cd ..

# Build functions
cd functions && npm run build && cd ..

# Deploy Cloud Functions
firebase deploy --only functions

# Deploy everything at once
firebase deploy
```

---

## 9. Environment Variables Reference

| Variable | Required | Description |
|---|---|---|
| `NEXT_PUBLIC_FIREBASE_API_KEY` | YES | Firebase web API key |
| `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` | YES | Firebase auth domain |
| `NEXT_PUBLIC_FIREBASE_PROJECT_ID` | YES | Firebase project ID |
| `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` | YES | Firebase storage bucket |
| `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID` | YES | Firebase messaging sender ID |
| `NEXT_PUBLIC_FIREBASE_APP_ID` | YES | Firebase app ID |
| `NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID` | No | Google Analytics measurement ID |
| `FIREBASE_ADMIN_PROJECT_ID` | YES | Firebase project ID (server-only) |
| `FIREBASE_ADMIN_CLIENT_EMAIL` | YES | Service account email (server-only) |
| `FIREBASE_ADMIN_PRIVATE_KEY` | YES | Service account private key (server-only) |
| `NEXT_PUBLIC_FUNCTIONS_URL` | YES | Cloud Functions base URL |
| `NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME` | No | Cloudinary cloud name for media |
| `NEXT_PUBLIC_CLOUDINARY_UPLOAD_PRESET` | No | Cloudinary unsigned upload preset |
| `CLOUDINARY_API_KEY` | No | Cloudinary API key (server-only) |
| `CLOUDINARY_API_SECRET` | No | Cloudinary API secret (server-only) |
| `NEXT_PUBLIC_APP_DOMAIN` | No | Your app's public URL |
| `NEXT_PUBLIC_VAPID_KEY` | No | VAPID key for push notifications |
| `RESEND_API_KEY` | No | Email via Resend |
| `OPENAI_API_KEY` | No | AI moderation / captions |
| `STRIPE_SECRET_KEY` | No | Stripe for premium subscriptions |
| `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` | No | Stripe public key |

---

## 10. Post-Deploy Checklist

After your site is live, do these in order:

- [ ] Add Vercel/Netlify URL to **Firebase Auth → Authorized domains**
- [ ] Deploy Firestore rules: `firebase deploy --only firestore:rules`
- [ ] Deploy Storage rules: `firebase deploy --only storage:rules`
- [ ] Deploy Firestore indexes: `firebase deploy --only firestore:indexes`
- [ ] Deploy Cloud Functions: `firebase deploy --only functions`
- [ ] Create an admin user in Firebase Auth → Firestore → set `role: "super_admin"` on their user doc
- [ ] Set up Cloudinary account and create an **unsigned upload preset** called `medpulse_uploads`
- [ ] Enable Firebase App Check (optional but recommended for production)
- [ ] Set up custom domain (see below)
- [ ] Test guest browsing (no account needed)
- [ ] Test registration and login
- [ ] Test video upload
- [ ] Test admin panel at `/admin`

---

## 11. Custom Domain Setup

### Vercel

1. Vercel Dashboard → Your project → **Settings** → **Domains**
2. Click "Add Domain" → type your domain (e.g. `medpulse.com`)
3. Follow DNS instructions — add CNAME or A record to your domain registrar
4. Wait for SSL to provision (~5 minutes)
5. Add the custom domain to **Firebase Auth → Authorized domains**

### Netlify

1. Netlify Dashboard → Site settings → **Domain management**
2. Click "Add custom domain" → enter your domain
3. Follow DNS instructions
4. SSL is automatic via Let's Encrypt
5. Add the custom domain to **Firebase Auth → Authorized domains**

---

## 12. Troubleshooting

### Build fails: "Cannot find module @/lib/firebase"
- Make sure `tsconfig.json` has `"paths": { "@/*": ["./*"] }`
- This is already configured in the project

### Firebase Auth: "auth/unauthorized-domain"
- Go to Firebase Console → Authentication → Settings → Authorized domains
- Add your deployment URL (e.g. `your-app.vercel.app`)

### Firestore: "Missing or insufficient permissions"
- Deploy the security rules: `firebase deploy --only firestore:rules`
- Make sure you're using the rules in `firestore.rules`, not `firestore.rules.example`

### Functions deploy fails
- Make sure you're on the **Blaze (pay-as-you-go)** Firebase plan
- Run `cd functions && npm install && npm run build && cd ..` first
- Check Node version: functions require Node 20

### Environment variables not working in production
- Variables prefixed with `NEXT_PUBLIC_` are exposed to the browser
- Variables without that prefix are server-only (API routes, Server Components)
- Re-deploy after adding new env variables on Vercel/Netlify

### "Module not found: react-hot-toast"
```bash
npm install react-hot-toast
```

### Page shows blank / white screen
- Check browser console for errors
- Make sure all `NEXT_PUBLIC_FIREBASE_*` variables are set correctly
- The Firebase API key must be the one from "Web apps" (not service account)

---

## Support

- Platform: [GitHub Issues](https://github.com/your-repo/medpulse-v6/issues)
- Firebase docs: [https://firebase.google.com/docs](https://firebase.google.com/docs)
- Next.js docs: [https://nextjs.org/docs](https://nextjs.org/docs)
- Vercel docs: [https://vercel.com/docs](https://vercel.com/docs)
- Netlify docs: [https://docs.netlify.com](https://docs.netlify.com)
